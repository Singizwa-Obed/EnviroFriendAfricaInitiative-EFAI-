export default function App(){
return (
<div style={{fontFamily:'sans-serif',padding:'2rem'}}>
<h1>Enviro Friend Africa Initiatives</h1>
<p>Creating a Greener Africa Through Plastic Collection, Recycling, Tree Planting, and Community Empowerment.</p>
<button>Become a Volunteer</button>
<button style={{marginLeft:10}}>Connect With Us</button>
<button style={{marginLeft:10}}>Deliver Plastic Waste</button>
</div>
)
}
