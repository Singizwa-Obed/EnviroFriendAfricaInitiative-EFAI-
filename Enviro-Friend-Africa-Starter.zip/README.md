# Enviro Friend Africa Initiatives

Starter project plan.

Pages:
- Home
- About
- Programs
- Volunteer
- Deliver Plastic Waste
- Contact

Hero slogan:
Creating a Greener Africa Through Plastic Collection, Recycling, Tree Planting, and Community Empowerment.
